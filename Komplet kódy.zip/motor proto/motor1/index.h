const char MAIN_page[] PROGMEM = R"=====(
<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <style>tab-table, th, td {border: 1px solid black;border-collapse:
collapse;text-align: center;}</style>
  </head>


// buttons
  <div class="button"align="center">
    <button type="start" class="btn btn-success" style="margin:2%;
height:45px; width:28%; margin-top:40px;">Start</button>
    <button type="button" class="btn btn-primary"style="margin:2%;
height:45px; width:28%; margin-top:40px;">Pause</button>
    <button type="button" class="btn btn-danger"style="margin:2%;
height:45px; width:28%; margin-top:40px;">Reset</button>
  </div>


// table
  <body>
    <table style="margin-top:20px; width:92.8%; margin-left:3.6%; ">
      <tr>
        <th style="height:45px; width:40%">Name</th>
        <th style="height:45px; width:20%">X location</th>
        <th style="height:45px; width:20%">Y location</th>
      </tr>
      <tr>
        <td bgcolor="#D3D3D3" style="height:45px; width:40%">Location 1</td>

////////////////
// Here I update number in tab, it is called adc because of some other code I used for this. Will change later
/////////////////
        <td bgcolor="#D3D3D3" style="height:45px; width:20%"><span id="ADCValue">0</span></td>
        <td bgcolor="#D3D3D3" style="height:45px; width:20%"><span
id="Y1">Y</span></td>
      </tr>
      <tr>
        <td style="height:40px; width:45%">Location 2</td>
        <td style="height:45px; width:20%">X</td>
        <td style="height:45px; width:20%">Y</td>
      </tr>
      <tr>
        <td bgcolor="#D3D3D3" style="height:45px; width:40%">Location 3</td>
        <td bgcolor="#D3D3D3" style="height:45px; width:20%">X</td>
        <td bgcolor="#D3D3D3" style="height:45px; width:20%">Y</td>
      </tr>
    </table>
  </body>

</html>

<body>
 
<script>
 
setInterval(function() {
  // Call a function repetatively with 2 Second interval
  getData();
}, 2000); //2000mSeconds update rate
 
function getData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("ADCValue").innerHTML =
      this.responseText;   // again, it is called adc because of some other code I used.
    }
  };
  xhttp.open("GET", "readADC", true);
  xhttp.send();
}
</script>
</body>
</html>
)=====";
